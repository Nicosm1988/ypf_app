# DATALIZA: Data e IA

Abrí `dataliza IA.html` con Chrome o Edge. Elegí Data o IA, conectá la carpeta común del negocio y elegí tu nombre. También podés probar con guardado local o demostración. Desde los botones superiores todos pueden consultar ambos equipos; elegir un nombre no es autenticación.

## Dónde configurar las carpetas

Buscá `const CARPETAS_EQUIPOS` al principio del JavaScript del HTML:

```js
const CARPETAS_EQUIPOS = {
  dataliza: "", // raíz seleccionada: conserva la ubicación anterior de Data
  ia: "IA"     // subcarpeta IA, creada al guardar por primera vez
};
```

Si seleccionás `C:\Negocio`, Data usa `C:\Negocio\dataliza_datos.json` e IA usa `C:\Negocio\IA\dataliza_ia_datos.json`. Para tener ambas en subcarpetas, cambiá `dataliza` a `"Data"` y colocá los archivos anteriores de Data en esa subcarpeta.

Las rutas son relativas a la carpeta común: podés usar `"Areas/IA"`, pero no una dirección absoluta ni `..`. El navegador requiere que selecciones la carpeta común y le des permiso; no puede acceder a una ruta solamente porque esté escrita en el código.

Cada área guarda en su destino la base, sus backups y sus tablas de Power BI. Actualizá las rutas de origen de Power BI si movés esos archivos.

## Llevarlo al trabajo

1. Guardá una copia de seguridad del HTML anterior y de los JSON actuales.
2. Copiá este HTML al entorno de trabajo y ajustá `CARPETAS_EQUIPOS` si corresponde. No requiere instalación de librerías ni servidor de base de datos.
3. Si ya había una base de IA en la carpeta raíz, mové manualmente `dataliza_ia_datos.json`, los `backup_ia_*.json` y las tablas `ia_*.json` a la subcarpeta `IA` antes de guardar cambios. La app no mueve ni fusiona bases automáticamente.
4. Abrí el HTML, elegí equipo y conectá la carpeta común. Verificá las tareas existentes antes de editar. El permiso y el guardado local no viajan con el HTML ni con GitHub: cada navegador debe conectar la carpeta compartida.

El funcionamiento en tu entorno depende de que Chrome/Edge y las políticas de la empresa permitan acceso a carpetas. El guardado local solo guarda en ese navegador; para compartir usen la carpeta común. Con carpetas sincronizadas, coordinen las escrituras: se detectan algunos conflictos, pero no hay transacciones entre computadoras.

## Validación

`node tests/storage.cjs` verifica separación de archivos, conservación de Data, backups y Power BI en IA, nuevos integrantes, detección de conflictos y rechazo de rutas fuera de la carpeta común.

## Validador de importaciones

En **Base → Importar JSON en este equipo**, el archivo se valida antes de normalizar o reemplazar datos. Los errores bloquean la importación y aparecen en Base con la ubicación exacta (`tasks[0].fecha` es la fecha de la primera tarea). Corregí el JSON y volvé a seleccionarlo.

Se revisan todos los bloques de la base, campos desconocidos, catálogos, personas activas del equipo, estados, prioridades, tipos, gates, fechas, identificadores y secuencia, listas, subtareas, enlaces, comentarios, historial, papelera, novedades y auditoría. Se conservan nombres históricos de autores y personas de tareas eliminadas aunque ya no integren el equipo.

Los posibles duplicados por nombre/proyecto y las tareas con negocio distinto al proyecto generan advertencias, porque Data admite tareas transversales. La confirmación muestra las advertencias y la cantidad de tareas actuales y entrantes. La importación sigue reemplazando la base completa; no combina archivos automáticamente. El validador verifica estructura y consistencia, no la veracidad del contenido ni que una eliminación sea intencional.

Los formatos antiguos incompletos o con campos adicionales deben adaptarse al esquema antes de importar; no se corrigen silenciosamente. Las bases ya conectadas siguen usando la lectura anterior: esta validación se aplica al botón de importación.

Ejecutá `node tests/import-validation.cjs` para probar casos inválidos, una importación válida y que los errores no modifiquen las bases. El ejemplo `ejemplos/ia_carga_inicial.ejemplo.json` es ilustrativo; no lo importes sobre datos reales.

## Política de guardado y recuperación

Desde esta versión, toda modificación que pasa por Guardar (tareas, proyectos, comentarios, movimientos, eliminaciones, importaciones y demás cambios de base) conserva versiones completas. Los campos de un formulario sin guardar no forman parte de estas versiones de base; se conservan además como borradores locales recuperables. Demo no guarda.

En modo carpeta, cada equipo utiliza `historial_backups/` dentro de su ubicación configurada. Antes de reemplazar la base principal se guarda y relee una copia de la base anterior, si existe, y una copia de la propuesta. Los nombres incluyen fecha/hora UTC y un identificador aleatorio. No se sobrescriben copias anteriores ni se eliminan por antigüedad. Las copias diarias de versiones anteriores del HTML no se eliminan y siguen en su ubicación original.

Si falla un respaldo o su verificación, no se escribe la base principal. Después de escribir la base se relee para comprobar el contenido antes de confirmar el guardado. Si falla esta verificación, la app avisa que no puede confirmar el guardado: hay que recargar y revisar antes de reintentar. Una propuesta respaldada puede corresponder a un cambio que no llegó a aplicarse. No se restaura ni fusiona automáticamente.

En modo local se aplica el mismo criterio con versiones en el almacenamiento del navegador. Si se agota la cuota, se bloquea el guardado; no se borran versiones para liberar espacio. El borrado del perfil del navegador puede eliminar tanto la base como sus respaldos locales.

Para recuperar: **Base → Ver y descargar respaldos**, descargar la versión deseada, revisarla, exportar primero la base actual y luego importar la versión recuperada. El validador de importación se mantiene activo; un respaldo antiguo puede requerir adaptar su estructura antes de importarlo. No perder ni reemplazar el archivo original al adaptarlo. Se debe revisar tanto la fecha como el sufijo `anterior` / `propuesta`.

### Segundo respaldo implementado; activación externa pendiente

La app ahora exige conectar un segundo destino desde Base para guardar en modo carpeta, verifica cada copia y conserva también los históricos existentes al conectarlo. La carpeta externa se recuerda, pero se debe reconectar su permiso en cada sesión. La conexión y la ejecución programada en el trabajo todavía no están activadas.

Las versiones en el mismo disco o carpeta no protegen contra pérdida del dispositivo, borrado de toda la carpeta o incidentes que afecten también sus copias. Para completar la política, el responsable de infraestructura debe configurar un respaldo automático independiente, con historial protegido contra borrado, acceso restringido y pruebas de restauración. Deben incluirse las bases de Data e IA, ambas carpetas `historial_backups` y el HTML/configuración. Hay que verificar el resultado de cada respaldo y alertar cuando falle; la app no ha configurado ese servicio externo.

No hay garantía absoluta de pérdida cero. Los archivos sincronizados tampoco ofrecen transacciones entre computadoras: conservar versiones permite recuperar contenidos, pero no combina ediciones simultáneas. Coordinar las escrituras sigue siendo necesario. Para edición concurrente fiable se requiere un servicio central con transacciones y respaldos administrados.

El historial crece con cada modificación: prever espacio y monitorearlo. No eliminar archivos automáticamente sin una política aprobada y una copia externa comprobada. Las consultas Power BI deben seleccionar sus archivos por nombre y evitar incluir recursivamente `historial_backups` como si fueran datos actuales.

## Completar la activación

La guía ejecutable está en [respaldo/OPERACION.md](respaldo/OPERACION.md). Incluye la conexión del segundo destino, la herramienta de copias completas independientes de la app, verificación y restauración en una carpeta nueva, y la configuración que debe activarse en el servidor real.

**Base → Recuperar borradores** conserva y recupera versiones locales del formulario de tareas y de novedades. No se restauran automáticamente ni se publican sin pulsar Guardar. Los nombres de usuario son identificación, no autenticación. **Base → Ver versiones del segundo respaldo** permite descargar las bases copiadas al otro destino.

Pruebas adicionales: `python3 -m unittest discover -s tests -p 'test_*.py'`. La herramienta `respaldo.py` se probó en este entorno Linux; la programación en el sistema operativo del trabajo no se probó ni se instaló.
