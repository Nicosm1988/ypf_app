const {readFileSync}=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const html=readFileSync('dataliza IA.html','utf8');
const script=html.split('<script>')[1].split('</script>')[0].split('(async function init()')[0];
const document={addEventListener(){}};
const sandbox={crypto:require("node:crypto").webcrypto,document,window:{addEventListener(){}},localStorage:{getItem(){return null}},console,setTimeout,clearTimeout};
vm.createContext(sandbox);
vm.runInContext(script,sandbox);
class Dir {
  constructor(){this.files=new Map();this.dirs=new Map()}
  async isSameEntry(other){return this===other}
  async resolve(other){if(this===other)return [];for(const [name,dir] of this.dirs){const path=await dir.resolve(other);if(path!==null)return [name,...path]}return null}
  async getDirectoryHandle(n,{create=false}={}) {if(!this.dirs.has(n)){if(!create)throw Object.assign(Error(),{name:'NotFoundError'});this.dirs.set(n,new Dir())}return this.dirs.get(n)}
  async getFileHandle(n,{create=false}={}) {if(!this.files.has(n)){if(!create)throw Object.assign(Error(),{name:'NotFoundError'});this.files.set(n,'')}const files=this.files;return {getFile:async()=>({text:async()=>files.get(n)}),createWritable:async()=>({write:async s=>files.set(n,s),close:async()=>{},abort:async()=>{}})}}
}
sandbox.external=new Dir();sandbox.root=new Dir();sandbox.assert=assert;
vm.runInContext(`(async()=>{
  baseDir=root;mode="folder";
  const data=emptyState();data.negocios=["Data existente"];
  await writeJSON(root,TEAMS.dataliza.file,data);
  const original=root.files.get(TEAMS.dataliza.file);
  assert.equal(await readDisk(root,"ia"),null);
  const c=await loadContext("ia");
  const next=emptyState();next.negocios=["IA independiente"];
  await assert.rejects(()=>persistCandidate("ia",c,next),/segundo destino/);
  externalBackupDir=root;
  await assert.rejects(()=>persistCandidate("ia",c,next),/fuera de la carpeta/);
  externalBackupDir=await root.getDirectoryHandle("nested",{create:true});
  await assert.rejects(()=>persistCandidate("ia",c,next),/fuera de la carpeta/);
  externalBackupDir=external;
  await persistCandidate("ia",c,next);
  assert.equal(root.files.get(TEAMS.dataliza.file),original);
  assert.equal(root.files.has(TEAMS.ia.file),false);
  assert.equal((await readDisk(root,"ia")).raw.negocios[0],"IA independiente");
  await persistCandidate("ia",c,next);
  const backups=root.dirs.get("IA").dirs.get("historial_backups");
  assert.equal(backups.files.size,3); // Primer candidato + anterior/candidato del segundo guardado.
  assert.ok([...backups.files.keys()].every(k=>k.startsWith("version_")));
  assert.ok([...backups.files.values()].every(raw=>JSON.parse(raw).negocios[0]==="IA independiente"));
  const externalHistory=external.dirs.get("DATALIZA_respaldo").dirs.get("ia");
  assert.equal(externalHistory.files.size,3);
  const preserved=new Map(backups.files);
  const primary=root.dirs.get("IA").files.get(TEAMS.ia.file);
  const signature=c.signature;
  const originalExternalGet=externalHistory.getFileHandle;
  externalHistory.getFileHandle=async()=>{throw new Error("Destino externo desconectado")};
  await assert.rejects(()=>persistCandidate("ia",c,{...next,seq:102}),/segundo respaldo/);
  assert.equal(root.dirs.get("IA").files.get(TEAMS.ia.file),primary);
  assert.equal(c.signature,signature);
  externalHistory.getFileHandle=originalExternalGet;
  const originalBackupGet=backups.getFileHandle;
  backups.getFileHandle=async()=>{throw new Error("Sin permiso para respaldar")};
  await assert.rejects(()=>persistCandidate("ia",c,{...next,seq:102}),/Sin permiso/);
  assert.equal(root.dirs.get("IA").files.get(TEAMS.ia.file),primary);
  assert.equal(c.signature,signature);
  backups.getFileHandle=originalBackupGet;
  const destination=root.dirs.get("IA"),originalGet=destination.getFileHandle;
  destination.getFileHandle=async function(name,options){if(name===TEAMS.ia.file&&options?.create)throw new Error("Falla escritura principal");return originalGet.call(this,name,options)};
  await assert.rejects(()=>persistCandidate("ia",c,{...next,seq:103}),/Falla escritura principal/);
  assert.equal(destination.files.get(TEAMS.ia.file),primary);
  assert.ok([...backups.files.values()].some(raw=>JSON.parse(raw).seq===103));
  for(const [name,raw] of preserved)assert.equal(backups.files.get(name),raw);
  destination.getFileHandle=originalGet;
  await persistCandidate("ia",c,{...next,seq:104});
  assert.ok(c.savedAt);
  assert.equal((await readDisk(root,"ia")).raw.seq,104);
  for(const [name,raw] of preserved)assert.equal(backups.files.get(name),raw);
  await exportStar(root,"ia",next);
  assert.ok(root.dirs.get("IA").files.has("ia_dim_persona.json"));
  assert.equal(root.files.has("ia_dim_persona.json"),false);
  assert.ok(TEAMS.ia.people.some(p=>p.n==="Gabriel Cataldi"));
  assert.ok(TEAMS.ia.people.some(p=>p.n==="Fernando Pronello"));
  await writeJSON(root.dirs.get("IA"),TEAMS.ia.file,{...next,seq:999});
  await assert.rejects(()=>persistCandidate("ia",c,next),/cambió/);
  CARPETAS_EQUIPOS.ia="../Data";
  await assert.rejects(()=>teamDirectory(root,"ia",true),/ruta/);
  console.log("OK: aislamiento, backups, Power BI, integrantes, conflictos y rutas");
})()`,sandbox).catch(e=>{console.error(e);process.exitCode=1});
