import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

spec = importlib.util.spec_from_file_location('respaldo', Path(__file__).resolve().parents[1] / 'respaldo/respaldo.py')
backup = importlib.util.module_from_spec(spec)
spec.loader.exec_module(backup)

class BackupTests(unittest.TestCase):
    def test_backup_restore_and_corruption(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder); source = root / 'datos'; source.mkdir()
            (source / 'IA').mkdir(); (source / 'IA' / 'datos.json').write_text('{"tasks": []}')
            (source / 'app.html').write_text('app')
            first = Path(backup.backup(source, root / 'externo')['archive'])
            original = first.read_bytes()
            second = Path(backup.backup(source, root / 'externo')['archive'])
            self.assertNotEqual(first, second); self.assertEqual(first.read_bytes(), original)
            self.assertEqual(len(backup.verify(first)['files']), 2)
            restored = root / 'recuperado'; backup.restore(first, restored)
            self.assertEqual((restored / 'IA/datos.json').read_bytes(), (source / 'IA/datos.json').read_bytes())
            with self.assertRaises(FileExistsError): backup.restore(first, restored)
            with self.assertRaises(ValueError): backup.backup(source, source / 'incorrecto')
            broken = root / 'corrupto.zip'
            with zipfile.ZipFile(first) as before, zipfile.ZipFile(broken, 'w') as after:
                for name in before.namelist(): after.writestr(name, b'error' if name == 'files/app.html' else before.read(name))
            with self.assertRaises(ValueError): backup.verify(broken)
            self.assertFalse((root / 'no_crear').exists())
            with self.assertRaises(ValueError): backup.restore(broken, root / 'no_crear')
            self.assertFalse((root / 'no_crear').exists())

    def test_traversal(self):
        for name in ['../escape', '/absolute', 'C:/Windows', 'a/../b', 'a\\b']:
            with self.assertRaises(ValueError): backup.safe_name(name)

if __name__ == '__main__': unittest.main()
