#!/usr/bin/env python3
"""Copias completas verificadas. Python 3.10+, sin dependencias externas.
No instala tareas programadas ni elimina versiones. Restaurar exige destino nuevo.
"""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import sys
import tempfile
import uuid
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def safe_name(name):
    path = PurePosixPath(name)
    if not name or path.is_absolute() or any(p in ('.', '..') for p in name.split('/')) or '\\' in name or ':' in name:
        raise ValueError('Ruta inválida en respaldo: ' + name)
    return path


def inventory(source):
    result = {}
    for path in sorted(source.rglob('*')):
        if path.is_symlink():
            raise ValueError('No se respaldan enlaces simbólicos: ' + str(path))
        if path.is_file():
            stat = path.stat()
            result[path.relative_to(source).as_posix()] = (stat.st_size, stat.st_mtime_ns)
    if not result:
        raise ValueError('La carpeta de origen está vacía.')
    return result


def verify(archive):
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            raise ValueError('Hay entradas duplicadas en el ZIP.')
        manifest = json.loads(z.read('manifest.json'))
        if manifest.get('format') != 1 or not isinstance(manifest.get('files'), dict) or not manifest['files']:
            raise ValueError('Manifiesto inválido.')
        expected = {'manifest.json'}
        for name, metadata in manifest['files'].items():
            safe_name(name)
            entry = 'files/' + name
            expected.add(entry)
            data = z.read(entry)
            if len(data) != metadata['size'] or digest(data) != metadata['sha256']:
                raise ValueError('Verificación fallida: ' + name)
        if set(names) != expected:
            raise ValueError('El ZIP contiene archivos no declarados.')
    return manifest


def backup(source, destination):
    source, destination = source.resolve(), destination.resolve()
    if not source.is_dir():
        raise ValueError('El origen debe ser una carpeta existente.')
    if source == destination or source in destination.parents or destination in source.parents:
        raise ValueError('Origen y destino deben ser carpetas separadas, sin contenerse.')
    entries = inventory(source)
    destination.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    final = destination / ('dataliza_' + stamp + '_' + uuid.uuid4().hex + '.zip')
    manifest = {'format': 1, 'createdAt': stamp, 'files': {}}
    fd, temp = tempfile.mkstemp(prefix='.incompleto_', suffix='.zip', dir=destination)
    os.close(fd)
    temporary = Path(temp)
    try:
        with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED) as z:
            for name, before in entries.items():
                safe_name(name)
                data = (source / name).read_bytes()
                stat = (source / name).stat()
                if before != (stat.st_size, stat.st_mtime_ns):
                    raise ValueError('El origen cambió durante el respaldo: ' + name)
                z.writestr('files/' + name, data)
                manifest['files'][name] = {'size': len(data), 'sha256': digest(data)}
            z.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
        if inventory(source) != entries:
            raise ValueError('El origen cambió durante la copia. Reintentá cuando no haya escrituras.')
        verify(temporary)
        if final.exists():
            raise ValueError('El nombre del respaldo ya existe.')
        temporary.replace(final)
        return {'archive': str(final), 'files': len(entries), 'verified': True}
    finally:
        # Solo se elimina el archivo incompleto de esta ejecución, nunca un respaldo.
        temporary.unlink(missing_ok=True)


def restore(archive, destination):
    manifest = verify(archive)
    destination = destination.absolute()
    # Nunca reemplazar una base o una restauración anterior.
    destination.mkdir(parents=True, exist_ok=False)
    with zipfile.ZipFile(archive) as z:
        for name, metadata in manifest['files'].items():
            relative = safe_name(name)
            target = destination.joinpath(*relative.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as handle:
                handle.write(z.read('files/' + name))
            if digest(target.read_bytes()) != metadata['sha256']:
                raise ValueError('No se verificó el archivo restaurado: ' + name)
    return {'restoredTo': str(destination), 'files': len(manifest['files']), 'verified': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--log', type=Path, help='Registro JSONL de éxitos y errores; ubicar fuera del origen.')
    sub = parser.add_subparsers(dest='command', required=True)
    b = sub.add_parser('backup'); b.add_argument('--source', type=Path, required=True); b.add_argument('--destination', type=Path, required=True)
    v = sub.add_parser('verify'); v.add_argument('--archive', type=Path, required=True)
    r = sub.add_parser('restore'); r.add_argument('--archive', type=Path, required=True); r.add_argument('--destination', type=Path, required=True)
    args = parser.parse_args()
    event = {'time': dt.datetime.now(dt.timezone.utc).isoformat(), 'command': args.command}
    try:
        if args.command == 'backup':
            if args.log and (args.log.resolve() == args.source.resolve() or args.source.resolve() in args.log.resolve().parents):
                raise ValueError('El log debe estar fuera del origen.')
            result = backup(args.source, args.destination)
        elif args.command == 'restore':
            result = restore(args.archive, args.destination)
        else:
            manifest = verify(args.archive)
            result = {'verified': True, 'files': len(manifest['files'])}
        event.update(ok=True, **result)
    except Exception as exc:
        event.update(ok=False, error=str(exc))
    if args.log:
        try:
            args.log.parent.mkdir(parents=True, exist_ok=True)
            with args.log.open('a', encoding='utf-8') as handle:
                handle.write(json.dumps(event, ensure_ascii=False) + '\n')
        except OSError as exc:
            event.update(ok=False, logError=str(exc))
    print(json.dumps(event, ensure_ascii=False))
    return 0 if event['ok'] else 1


if __name__ == '__main__':
    sys.exit(main())
