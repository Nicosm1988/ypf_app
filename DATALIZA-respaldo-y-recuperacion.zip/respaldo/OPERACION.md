# Activación del respaldo en el trabajo

Estado del paquete: código y pruebas listos; no conectado a los datos de trabajo ni programado en un servidor. No se han movido ni borrado datos productivos.

## Activar la app

1. Conservar el HTML anterior y una copia de las bases antes de reemplazar la aplicación.
2. Copiar `dataliza IA.html` de este paquete al entorno de trabajo. Mantener el bloque `CARPETAS_EQUIPOS` acorde a la ubicación existente: no mover Data por defecto.
3. Abrir en Chrome/Edge, elegir equipo y conectar la carpeta común del negocio. Se pueden consultar datos aunque todavía no se haya conectado el segundo respaldo.
4. En **Base → Conectar segundo respaldo**, elegir una carpeta en otro dispositivo o almacenamiento administrado. No puede estar dentro de la carpeta de datos ni contenerla. La app no puede comprobar si dos carpetas están físicamente en el mismo disco. Releer un archivo verifica la copia accesible localmente, no que OneDrive u otro servicio haya terminado de sincronizarlo a la nube.
5. La conexión copia las bases disponibles de ambos equipos, sus versiones acumuladas y sus copias diarias antiguas. Las copias están bajo `DATALIZA_respaldo/dataliza` y `DATALIZA_respaldo/ia`. Si falla una copia, se informa el error y no se considera conectada esa nueva selección.
6. El permiso del segundo destino debe reconectarse en cada nueva sesión desde Base. Cada guardado en modo carpeta exige copias verificadas en ambos destinos. Si el segundo destino no está disponible, el cambio no se escribe en la base principal.
7. Revisar **Base → Ver versiones del segundo respaldo**. Descargar y probar una recuperación antes de comenzar el uso real.

El modo local sigue siendo almacenamiento en un navegador, sin la obligación de segundo destino del modo carpeta. No usarlo como base compartida productiva. Demo no guarda datos.

## Respaldo completo independiente de la app

`respaldo.py` funciona con Python 3.10 o posterior, sin instalar librerías. Copia todos los archivos de la carpeta indicada, genera un ZIP nuevo, registra SHA-256 por archivo, verifica la copia y no elimina respaldos anteriores. El destino debe quedar fuera del origen, y viceversa. Rechaza enlaces simbólicos. Si el origen cambia durante la copia, falla en lugar de anunciar un respaldo válido.

Ejemplo (reemplazar las rutas por las reales):

```text
python respaldo.py --log "DESTINO/respaldo-eventos.jsonl" backup --source "ORIGEN" --destination "DESTINO"
python respaldo.py verify --archive "DESTINO/dataliza_FECHA_ID.zip"
python respaldo.py restore --archive "DESTINO/dataliza_FECHA_ID.zip" --destination "CARPETA_NUEVA_DE_PRUEBA"
```

La carpeta origen debe contener el HTML desplegado, Data, IA y sus `historial_backups`; si el HTML está fuera de esa carpeta, copiar su versión desplegada a un lugar incluido en el respaldo. No usar una carpeta de documentos ajenos a DATALIZA como origen. El ZIP incluye todos sus archivos.

Restaurar exige una carpeta inexistente; no sobrescribe la base actual. El resultado es JSON y el código de salida es `0` si se verificó, `1` ante error. El registro JSONL agrega éxitos y fallas, sin reemplazar entradas previas. Una restauración fallida puede dejar una carpeta parcial: revisar el error, conservarla para diagnóstico y reintentar en otra carpeta nueva.

## Programación y monitoreo pendientes de activar

La frecuencia y el destino deben acordarse con el responsable del entorno. El respaldo por cada guardado ya se ejecuta desde la app cuando ambos destinos están conectados; la copia completa programada agrega una capa independiente.

- **Windows:** crear una tarea en Programador de tareas con la ruta absoluta de Python como programa y los argumentos anteriores (incluida la ruta absoluta de `respaldo.py`). Configurar la cuenta que tenga permisos de lectura del origen y escritura del destino, ejecución sin depender de la sesión interactiva, reintentos y prevención de ejecuciones solapadas. No poner contraseñas en archivos de este paquete.
- **Linux:** usar el planificador del servidor con la misma orden y rutas absolutas. Ejecutar con una cuenta dedicada que tenga acceso a ambos destinos y monitorear el código de salida.
- Registrar el último respaldo exitoso y alertar en la herramienta corporativa si no llega en el intervalo acordado o aparece `ok: false`. Este paquete no configura ni envía avisos a terceros.
- Monitorear espacio libre tanto en origen como en destino. No limpiar versiones automáticamente.
- Aplicar protección contra borrados y retención administrada en el destino externo. No es una propiedad que un HTML pueda garantizar.

No se instaló ninguna tarea programada: faltan rutas, sistema operativo del servidor, cuenta de ejecución y acceso al almacenamiento real.

## Prueba de recuperación

1. Ejecutar una copia completa y verificar su ZIP.
2. Restaurarla con `restore` en una carpeta nueva de prueba.
3. Comparar cantidad de tareas, proyectos, comentarios y archivos de ambas áreas. El script ya compara hashes de los archivos restaurados.
4. Abrir el HTML restaurado y conectar exclusivamente las carpetas de prueba. No mezclar permisos o rutas productivas con esa prueba.
5. Registrar fecha, archivo recuperado y resultado; repetir después de cambiar el almacenamiento o la aplicación y con la periodicidad que defina el responsable operativo.

## Límites que siguen vigentes

Los bloqueos de la app coordinan pestañas del mismo origen/navegador, no computadoras diferentes. Véase [Web Locks API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Locks_API). Sigue siendo necesario coordinar escrituras entre usuarios en distintos equipos; un servicio central con transacciones requiere una decisión e infraestructura adicionales.

Las copias de borradores se generan al editar tareas/novedades y se conservan en el navegador, separadas por equipo y nombre de usuario. Se recuperan desde Base; no se envían automáticamente a la base ni al segundo respaldo. Si se agota la cuota o se borra el perfil del navegador, esa protección local no alcanza. No hay garantía absoluta frente a toda pérdida o incidente.
