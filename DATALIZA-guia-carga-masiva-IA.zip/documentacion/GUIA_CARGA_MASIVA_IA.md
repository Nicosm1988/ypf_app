# Preparar una carga masiva con ayuda de una IA

Esta guía sirve para usar `ia_carga_inicial.ejemplo.json` como modelo y preparar un JSON compatible con DATALIZA. No requiere Python ni llevar todo el repositorio.

**La importación reemplaza toda la base de IA.** Si ya hay datos, la IA que prepare la carga debe trabajar sobre una exportación actual completa y agregar lo nuevo conservando lo anterior. El modelo de ejemplo no es tu base productiva.

## Archivos que tenés que pasarle

1. [PROMPT_CARGA_MASIVA_IA.txt](PROMPT_CARGA_MASIVA_IA.txt): copiá su contenido al chat de la IA. Incluye el esquema, catálogos, reglas de conservación y verificaciones.
2. [ia_carga_inicial.ejemplo.json](../ejemplos/ia_carga_inicial.ejemplo.json): adjuntalo como referencia de estructura.
3. Tu listado real de iniciativas y tareas: puede ser una planilla, un documento o texto pegado.
4. Si ya existe cualquier información en IA: la exportación obtenida en **IA → Base → Exportar JSON del equipo**. Conservá otra copia intacta fuera de ese chat.
5. Opcionalmente, el HTML de la versión que usás para contrastar el validador y los integrantes si cambiaron.

No necesitás pasarle datos de Data para preparar una carga de IA. El ejemplo contiene nombres, fechas y un enlace ilustrativos: no tienen que aparecer en la carga final salvo que correspondan a información real de tu fuente.

## Elegí el tipo de carga

| Situación | Parámetro OPERACIÓN | Qué debe hacer la IA |
|---|---|---|
| La base de IA está realmente vacía y lo confirmaste | `CARGA_INICIAL` | Crear una base nueva con las tareas reales. |
| IA ya tiene tareas, catálogos, papelera, novedades o auditoría | `AGREGAR_A_EXISTENTE` | Conservar toda la exportación y agregar tareas nuevas. |
| Querés modificar o eliminar tareas anteriores | Este prompt no lo autoriza | Preparar una instrucción y revisión específica para esos cambios. |

Tener cero tareas activas no implica que toda la base esté vacía.

## Completá el encabezado del prompt

Ejemplo de encabezado para agregar tareas (reemplazá los valores entre corchetes antes de enviarlo):

```text
- EQUIPO DESTINO: IA.
- OPERACIÓN: AGREGAR_A_EXISTENTE.
- FECHA_CARGA: [fecha real de preparación, AAAA-MM-DD].
- BASE IA VACÍA CONFIRMADA: NO.
- ARCHIVO DE BASE ACTUAL: [nombre de la exportación adjunta].
- FUENTE DE INICIATIVAS: [nombre del archivo o texto que adjuntás].
- VALORES INICIALES AUTORIZADOS PARA CAMPOS OMITIDOS: NINGUNO.
- ACLARACIONES: Conservar todos los datos existentes. Agregar únicamente las tareas indicadas.
```

Si querés que las tareas nuevas sin estado informado comiencen en `No iniciado`, con gate `backlog` y prioridad `⚪ Sin asignar`, podés autorizar esos tres valores en el encabezado. Esto no autoriza inventar responsables, fechas ni tareas.

La fecha de carga se usa para `createdAt` y `updatedAt` de los registros nuevos. La fecha estimada de cada tarea es otro dato: debe venir de tu fuente o de una decisión tuya.

## Cómo preparar la información de entrada

Una iniciativa corresponde a un **proyecto**. Cada fila de la planilla representa una **tarea** de ese proyecto. Repetí el proyecto si tiene varias tareas.

Columnas recomendadas:

| Columna | Qué completar |
|---|---|
| Referencia de fila | Un código de tu planilla para rastrear la conversión; no se agrega como campo nuevo al JSON. |
| Negocio | Nombre del negocio. |
| Proyecto / iniciativa | Nombre único de la iniciativa dentro de IA. |
| Nombre de tarea | Acción concreta que se cargará. |
| Descripción | Alcance informado, si lo hay. |
| Sub negocio | Si corresponde. |
| Tipo de activo | `app`, `fabric`, `flow` u `otro`, según la clasificación actual. |
| Estado | Estado de esa tarea. |
| Prioridad | Fuego, Alta, Media, Baja o Sin asignar; el prompt convierte al literal con emoji. |
| Gate | `backlog`, `g1` a `g10`, o `lecciones`. |
| Responsable | Una persona del equipo IA, con nombre completo. |
| Fecha de inicio | Opcional, `AAAA-MM-DD`. |
| Fecha estimada | Obligatoria, `AAAA-MM-DD`. |
| Involucrados | Nombres completos; si son varios, usar una lista o separarlos con `;`. |
| Subtareas | Cada texto y si está completado; también pueden ir en una hoja aparte vinculada a la referencia de fila. |
| Documentación | Nombre y URL de cada enlace; también puede ir en una hoja vinculada. |

No hace falta que el equipo invente IDs, auditorías o historias. La IA asignará IDs nuevos con las reglas del prompt y conservará los históricos existentes. El código actual etiqueta `otro` como HTML: un chatbot no debe clasificarse automáticamente ahí sin que lo autorices.

El prompt contiene todos los campos internos y sus valores admitidos. Para detalles exactos de comentarios, historial, papelera, novedades, auditoría y secuencia, usá ese archivo como referencia única.

## Qué debe devolverte la IA

Si falta información, primero una tabla de preguntas por fila y campo. Es el resultado correcto: no debería inventar datos para terminar rápido.

Cuando los datos estén completos:

- `ia_carga_masiva_preparada.json`, con la base entera, sin puntos suspensivos ni secciones omitidas.
- Un informe separado con cantidad de tareas antes/nuevas/después, proyectos nuevos, IDs, secuencia, advertencias y comprobaciones realizadas.
- La correspondencia entre filas de tu fuente y tareas generadas.

El informe no debe ir dentro del JSON porque el validador rechaza campos desconocidos. Pedí archivo adjunto si la base es grande; no copies una respuesta truncada como si fuera el archivo completo.

## Revisión e importación

1. Coordiná que no cambie la base mientras se prepara e importa la carga. Si alguien la modificó desde la exportación, volvé a exportar y pedí rehacer la combinación con esa versión reciente.
2. Comprobá que el total final sea el anterior más las tareas nuevas autorizadas. Si había 20 y se agregan 5, debe haber 25.
3. Revisá que todas las tareas anteriores sigan presentes con sus IDs y valores; también papelera, comentarios, históricos, novedades, auditoría y catálogos. La IA debe reportar cero modificaciones y cero eliminaciones anteriores en este flujo.
4. Revisá las nuevas tareas: responsables, fechas, tipo, gate, proyecto y negocio. Confirmá que no haya quedado la tarea ni el enlace demostrativo del ejemplo.
5. En DATALIZA, elegí **IA**, tu nombre y la carpeta madre correcta. En modo carpeta, conectá también el segundo respaldo desde Base; no uses Demo para la carga real.
6. Guardá una exportación de seguridad de la base actual y abrí **Base → Importar JSON en este equipo**.
7. Elegí el archivo preparado. Si el validador muestra errores, copiá su mensaje a la IA y pedí corregir el archivo sin tocar datos anteriores. Volvé a revisar la entrega.
8. Confirmá únicamente si el destino indica **Equipo IA**, el total coincide y las advertencias fueron revisadas. La app no mezcla automáticamente: reemplaza con el contenido completo recibido.
9. Esperá la confirmación de importación, comprobá el resultado en las pantallas y exportá la base final para verificarla. No confirmes éxito si la app informa que no pudo guardar o verificar el respaldo.

El validador revisa estructura y consistencia, pero no sabe si una tarea faltante se omitió por error ni si una fecha inventada es verdadera. Un prompt ayuda a preparar la carga; no reemplaza la revisión ni garantiza que otra IA acierte siempre.

## Mensaje corto para acompañar los adjuntos

Después de pegar el prompt completo y completar sus parámetros, podés cerrar con:

> Te adjunto el modelo de estructura, la exportación actual del equipo IA y las nuevas iniciativas. Prepará una ampliación de la base completa siguiendo el prompt. Conservá íntegramente todos los registros anteriores. Antes de generar el archivo, preguntame por los datos obligatorios faltantes y los posibles duplicados. No importes nada ni uses los datos ilustrativos del modelo como datos reales.

Para una primera carga vacía, cambiá esa instrucción por:

> Confirmo que la base de IA está vacía y no tiene información anterior que conservar. Te adjunto el modelo y las iniciativas reales. Prepará la carga inicial siguiendo el prompt, sin incorporar los datos demostrativos del modelo. Preguntame por los campos obligatorios faltantes antes de entregar el JSON final.
